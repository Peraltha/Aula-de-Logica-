﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcProjectOne
{
    public partial class frmCalcOne : Form
    {
        public frmCalcOne()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 + Num2;
            MessageBox.Show ("Soma:" + resultado);
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 - Num2;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnDividido_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 / Num2;
            MessageBox.Show("Dividido:" + resultado);
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 * Num2;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void frmCalcOne_Load(object sender, EventArgs e)
        {
        }

        private void btnVirus_Click(object sender, EventArgs e)
        {
        
        }
    }
}

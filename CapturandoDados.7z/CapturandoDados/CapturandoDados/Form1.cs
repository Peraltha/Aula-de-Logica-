﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conquista clicou na label Inteiro");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou o texto");
        }

        private void lblText_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conquista clicou na label Texto");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou o texto");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conquista clicou na label Decimal");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alteurou o texto");
        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conquista clicou na label Boleano");
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou o texto");
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O formulario foi enviado com sucesso");
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Limpado");
        }
    }
}
